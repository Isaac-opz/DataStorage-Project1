package com.backend.doctic_mongo.Model.ENUM;

public enum PublicoEnum {
    Si,
    No
}