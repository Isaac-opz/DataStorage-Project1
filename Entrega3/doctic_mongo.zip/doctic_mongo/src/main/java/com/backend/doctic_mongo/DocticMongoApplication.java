package com.backend.doctic_mongo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocticMongoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DocticMongoApplication.class, args);
	}

}
