package com.backend.doctic_mongo.Model.ENUM;

public enum EstadoEnum {
    activa,
    inactiva
}