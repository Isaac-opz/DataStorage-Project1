package com.platform.doctic_project.Model.ENUM;

public enum Publico {
    Si,No
}
