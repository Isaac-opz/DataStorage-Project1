package com.platform.doctic_project.Model.ENUM;

public enum EstadoContrasena {
    activa, inactiva 

}
