package com.platform.doctic_project.Exception;

public class RecursoNoEncontradoException extends RuntimeException{

    public RecursoNoEncontradoException(String mensaje) {
        super(mensaje);
    }
    
}
