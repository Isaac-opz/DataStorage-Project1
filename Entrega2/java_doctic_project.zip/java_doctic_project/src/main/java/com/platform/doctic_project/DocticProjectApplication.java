package com.platform.doctic_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocticProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DocticProjectApplication.class, args);
	}

}
