package com.platform.doctic_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocticProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
